//
//  main.m
//  YQAsyncBlock
//
//  Created by Yaqiang Wang on 2018/11/19.
//  Copyright © 2018 Yaqiang Wang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
