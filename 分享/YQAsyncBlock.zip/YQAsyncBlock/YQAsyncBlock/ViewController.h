//
//  ViewController.h
//  YQAsyncBlock
//
//  Created by Yaqiang Wang on 2018/11/19.
//  Copyright © 2018 Yaqiang Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

